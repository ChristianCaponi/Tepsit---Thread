
public class Contatore {

	int contatore =0;

	public int incrementa(int limit) {
		
		if(contatore<limit){
			
			contatore++;
			
		return contatore;
		
		}else{
			return -1;
		}
	}
}
