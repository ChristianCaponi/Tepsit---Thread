//Christian Caponi 5°CI 01/01/24

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Contatore contatore = new Contatore();
		
		int t;
		int n;

		Scanner input =new Scanner(System.in);

		System.out.println("Inserisci il numero di Thread:");
		t = input.nextInt();
		
		System.out.println("Inserisci il limite del contatore:");
		n = input.nextInt();
		
		
		for(int i=0;i<t;i++){
			
			Thread Thread = new Thread(new Incrementatore(contatore,n));
			
			Thread.start();
		}

	}

}
