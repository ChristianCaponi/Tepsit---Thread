
public class Incrementatore implements Runnable {
	
	private Contatore contatore;
	
	private int limite;
	
	public void setLimit(int l){
	limite = l;	
	}
	
	public Incrementatore(Contatore contatore,int limite) {
		
		this.contatore = contatore;
		this.limite = limite;
	}
	
	public void run(){
		
		while(true){
			int valore = contatore.incrementa(limite);
		
		if(valore == -1)
			break;
		System.out.println(Thread.currentThread().getName() + " " + valore);
		}
	}
	
}
