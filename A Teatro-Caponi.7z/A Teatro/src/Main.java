//Christian Caponi 5°CI 01/01/24

//Per il completamento dell'esercizio è stato impiegato l'uso di Chat GPT per aiutarmi in parti di codice non ben chiare

public class Main{

	public static void main(String[] args) {

		Teatro teatro = new Teatro();

        //Creo 7 Thread
        for (int i = 0; i < 7; i++) {
        	
        	int file = 0;
        	
            int File = i % file;  
            
            new Thread(() -> {
                for (int t = 0; t < 3; t++){  
                	
                    if (!teatro.Prenota(File)) {
                        break;
                    }
                }
                
            }, "Thread " + (i + 1)).start();
        }

        
        
        try {
        	
            Thread.sleep(10000);			//Attendo 10 secondi
            
        } catch(InterruptedException e) {
            
        	System.out.println("Errore");
        	
        }

        System.out.println("Posti disponibili " + teatro.PostiLiberi());
    }
		
}

