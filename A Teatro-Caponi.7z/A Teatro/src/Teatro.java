//Christian Caponi 5°CI 01/01/24

public class Teatro{
	
    private int file = 15;					//Variabile che contiene le file del teatro
    private int posti = 46;					//Variabile che contiene i posti del teatro
    private int postiC = posti / 2;			//Variabile che contiene i posti centralli del teatro
    private boolean[][] postiA;				//Array di booleani che guardarà i posti OCCUPATTI e quelli LIBERI

    public Teatro(){
    	
    	postiA = new boolean[file][posti];		//Qui tutti i posti sono disponibili
    }

    
    //Grazie a synchronized solo un thread alla volta può eseguire il metodo
    public synchronized boolean Prenota(int file){
    	
        for (int i = 0; i <= postiC; i++) {
        	
            int s;			//Variabile che indica il posto a sinistra del centro     
            int d;			//Variabile che indica il posto a destra del centro 
            
            s = postiC - i;
            d = postiC + i;
            
            //Prenoto il posto più a sinistra
            if (!postiA[file][s]){
            	
            	postiA[file][s] = true;
            	
                System.out.println(Thread.currentThread().getName() + " hai prenotato il posto " + (s + 1));
                return true;
             
              //Prenoto il posto più a destra   
            }else if(d < posti && !postiA[file][d]){
            	
            	postiA[file][d] = true;
            	
                System.out.println(Thread.currentThread().getName() + " hai prenotato il posto " + (d + 1));
                return true;
            }
        }
        
        System.out.println(Thread.currentThread().getName() + " i posti nella fila " + (file + 1) + " sono occupati.");
        return false;
    }

    
    //Metodo che conta i posti liberi
    public synchronized int PostiLiberi() {
    	
        int contatore = 0;
        
        //Scoro grazie al doppio For tutto l'array
        for (int i = 0; i < file; i++){
        	
            for (int j = 0; j < posti; j++){
            	
            	//Se il posto cercato è disponibile incremento il contatore
                if (!postiA[i][j]){
                	contatore++;
                }
            }
        }
        
        return contatore;
	
    }
    
}
