//Christian Caponi 5°CI 01/01/24

public class Contatore extends Thread{
	
	private int Id;				//Variabile che contiene l'id del thread
    private int max;			//Variabile che contiene il massimo a cui il thread deve contare
    private int Valore;			//Variabile che contiene il valore del conteggio

    //Costruttore
    public Contatore(int Id, int max){
        this.Id = Id;
        this.max = max;
        this.Valore = 0;
    }

    //Restituisce l'Id del thread
    public int getThreadId() {
        return Id;
    }

    //restituisce il valore del conteggio del thread
    public int getCurrentValue() {
        return Valore;
    }

    public void run() {
        while (Valore <= max) {
        	
        	Valore++;
        	
            try {
            	
                Thread.sleep(120);		//Attendo 120ms
                
            }catch(InterruptedException e){
            	
            	System.out.println("Errore");
            }
        }
    }
}
