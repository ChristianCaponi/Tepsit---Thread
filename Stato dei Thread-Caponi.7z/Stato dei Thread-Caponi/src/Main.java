//Christian Caponi 5°CI 01/01/24

//Per il completamento dell'esercizio è stato impiegato l'uso di Chat GPT per aiutarmi in parti di codice non ben chiare

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		//Dichiarazione delle Variabili
		
		int t; 			//Numero di thread
        int n; 			//Valore massimo fino a cui contare
		
        //Gestione Input Utente
		Scanner input = new Scanner(System.in);
        
        System.out.println("Inserisci il numero di Thread:");
		t=input.nextInt();
		
		System.out.println("Inserisci il Valore massimo fino a cui contare:");
		n=input.nextInt();

		
        //Creazione dei thread
		
		Contatore[] threads = new Contatore[t];			//Creo un Array che conterrà i Thread

        for (int i = 0; i < t - 1; i++){
        	
            threads[i] = new Contatore(i, n);			//Creo l'oggetto Contatore assegnando il thread al proprio indice
            threads[i].start();							//Avvio i thread
        }

        
        //Controllo dello stato dei thread
        
        boolean Completato = false;						//Variabile che servirà a sapere se tutti i thread hanno terminato
        
        while (!Completato) {
        	Completato = true;							//Assumo che tutto sia finito in caso contrario tornerà FALSE

            for (int i = 0; i < t-1; i++) {
            	
            	//Controllo se il thread è attivo
                if (threads[i].isAlive()) {
                	
                	Completato = false;		//Se è attivo allora ancora tutti i thread non sono terminati
                	
                    System.out.println("Thread numero " + threads[i].getThreadId() + "conta fino a " + threads[i].getCurrentValue());
                } else {
                    System.out.println("Thread numero " + threads[i].getThreadId() + "completato");
                }
            }
            
            
            try {
            	
                Thread.sleep(1000);			//Attessa di 1 secondo
                
            } catch (InterruptedException e){
            	
            	System.out.println("Errore");
            }
        }

        System.out.println("Tutti i thread sono terminati");
    	}
	}

